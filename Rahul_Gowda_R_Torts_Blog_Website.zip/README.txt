RAHUL GOWDA R — TORT LAW BLOG WEBSITE

Open index.html in a browser to use the website.

The site is a standalone static website. It needs no database or server.
To publish it, upload index.html to a static hosting service.
